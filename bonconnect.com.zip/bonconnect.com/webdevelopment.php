<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <link rel="icon" href="assets/img/web.png">
<title>Web Development</title>
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alef">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alegreya+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Average+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cabin+Condensed">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lora">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
    <link rel="stylesheet" href="assets/css/-product-features.css">
    <link rel="stylesheet" href="assets/css/Article-Clean.css">
    <link rel="stylesheet" href="assets/css/dh-highlight-left-right.css">
    <link rel="stylesheet" href="assets/css/Features-Boxed-Remixed-1.css">
    <link rel="stylesheet" href="assets/css/Features-Boxed-Remixed-2.css">
    <link rel="stylesheet" href="assets/css/Features-Boxed-Remixed.css">
    <link rel="stylesheet" href="assets/css/Features-Boxed.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="assets/css/Header-Dark.css">
    <link rel="stylesheet" href="assets/css/Highlight-Clean.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div>
        <div class="header-dark" style="background-image: url(&quot;assets/img/comingsoon.jpg&quot;);font-family: Montserrat, sans-serif;height: 500px;">
        <nav class="navbar navbar-dark navbar-expand-md navigation-clean-search" style="font-family: Montserrat, sans-serif;">
                <div class="container"><img class="pulse animated infinite" src="assets/img/Untitled_design__1_-removebg-preview%20(1).png" style="height: 130px;filter: brightness(200%) contrast(200%) grayscale(100%) invert(0%) saturate(200%);font-size: 16px;"><button data-toggle="collapse" class="navbar-toggler"
                        data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navcol-1">
                        <ul class="nav navbar-nav">
                            <li class="nav-item" role="presentation"><a class="nav-link" href="index.php">Home</a></li>
                            <li class="nav-item" role="presentation"><a class="nav-link" href="#features">About Us</a></li>
                            <li class="nav-item" role="presentation"><a class="nav-link" href="#contactmap">Contact Us</a></li>
                            <li class="dropdown nav-item"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#">Services&nbsp;</a>
                                <div class="dropdown-menu" role="menu" style="opacity: 1.0;">
                            
                               
                                <a class="dropdown-item" role="presentation" href="ISP.php">Internet Service Provider (ISP)</a>
                            
                                <a class="dropdown-item" role="presentation" href="MobileApplicationDevelopment.php">Mobile App Development </a>
                                <a class="dropdown-item" role="presentation" href="iot.php">Internet of Things (IoT)</a>
                                <a class="dropdown-item" role="presentation" href="webdevelopment.php">Web Development</a>
                            
                            </div>
                            </li>

                            <li class="dropdown nav-item"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#">Vacancies&nbsp;</a>
                                <div class="dropdown-menu" role="menu" style="opacity: 1.0;">
                                <a class="dropdown-item" role="presentation" href="vacancies.php">Internships / Learnerships</a>
                              
                            </div>
                            </li>
                           
                        </ul>
                    </div>
                </div>
                <div  id="google_translate_element" ></div>
            </nav>
    </div>
    </div>
    <div class="article-clean">
        <div class="container">
            <div class="row" style="font-family: Montserrat, sans-serif;">
                <div class="col-lg-10 col-xl-8 offset-lg-1 offset-xl-2">
                  <br><br>
                    <h1 class="text-left" data-aos="fade-up-right" style="color: rgb(0,32,64);">Web Development</h1>
                    <div class="text">
                    <h2 data-aos="fade-up-right" style="font-size: 30px;color: rgb(0,32,64);line-height: 46px;font-weight: normal;">Our Web Services</h2>
                        <h2 data-aos="fade-up-right" style="font-size: 23px;color: rgb(0,32,64);line-height: 46px;font-weight: normal;">Innovative Web Designing</h2>
                        <p data-aos="fade-up-right" style="font-family: Montserrat, sans-serif;color:  rgb(0,32,64);">The websites designed by us are of innovative designs which drive great conversions. We place the usability features strategically to provide ease to the customers for booking.<br></p>
                        <h2 data-aos="fade-up-right" style="font-size: 23px;color: rgb(0,32,64);line-height: 46px;font-weight: normal;">Relevant Information</h2>
                        <p data-aos="fade-up-right" style="font-family: Montserrat, sans-serif;color:  rgb(0,32,64);">The website development by us is easy to navigate and we strive to display high-quality content in an engaging format which enables the user to find genuine information quickly.<br></p>
                        <h2 data-aos="fade-up-right" style="font-size: 23px;color: rgb(0,32,64);line-height: 46px;font-weight: normal;">Attractive Logo and Layout</h2>
                        <p data-aos="fade-up-right" style="font-family: Montserrat, sans-serif;color:  rgb(0,32,64);">We understand the decision of colour selection as a piece of desirable information to your target right audience. We are excellent in choosing the colours, logos and shades that make your website much appealing and unique.<br></p>
                        <h2
                            data-aos="fade-up-right" style="font-size: 23px;color: rgb(0,32,64);line-height: 46px;font-weight: normal;">Responsive Web Development</h2>
                            <p data-aos="fade-up-right" style="font-family: Montserrat, sans-serif;color:  rgb(0,32,64);">The website design created by our developers will have responsive web development to display seamlessly across all the browsers and platform, from mobile phones and tablets to laptops and desktops.<br></p>
                            <h2 data-aos="fade-up-right"
                                style="font-size: 23px;color: rgb(0,32,64);line-height: 46px;font-weight: normal;">High-Quality Templates</h2>
                            <p data-aos="fade-up-right" style="font-family: Montserrat, sans-serif;color:  rgb(0,32,64);">While developing the website our professional website designer team designs superlative quality images that perfectly suits on each web page. We have a collection of high-quality images, infographics and also accommodate any
                                multimedia request.<br></p>
                            <h2 data-aos="fade-up-right" style="font-size: 23px;color: rgb(0,32,64);line-height: 46px;font-weight: normal;">Performance Optimization<br></h2>
                            <p data-aos="fade-up-right" style="font-family: Montserrat, sans-serif;color:  rgb(0,32,64);">Source code of a website plays a vital role in making the website powerful and distinct. The website designed by us generates user engagement, retention and conversion with optimized webpages and easy navigation.<br></p>
                            <h2
                                style="font-size: 32px;color: rgb(0,32,64);line-height: 46px;font-weight: normal;">Our Web Development Template Features<br></h2>
                                <ul>
                                    <li data-aos="fade-up-right" style="font-size: 16px;color:  rgb(0,32,64);">Enriched user experience in building websites globally.<br></li>
                                    <li data-aos="fade-up-right" style="font-size: 16px;color:  rgb(0,32,64);">Experienced website developers, content developers and developers.<br></li>
                                    <li data-aos="fade-up-right" style="font-size: 16px;color:  rgb(0,32,64);">Website developed by us exactly reflects your branding.<br></li>
                                    <li data-aos="fade-up-right" style="font-size: 16px;color:  rgb(0,32,64);">Provide a complete digital marketing solution which in result offer better business and better ranking<br></li>
                                    <li data-aos="fade-up-right" style="font-size: 16px;color:  rgb(0,32,64);">Our package consists of an online marketing plan which helps you in making digital marketing avenues<br></li>
                                </ul>
                    </div>
                    <h2 style="color: rgb(0,32,64);">What to Expect?<br></h2>
                    <ul>
                        <li data-aos="fade-up-right" style="font-size: 16px;color:  rgb(0,32,64);">Custom, creative designs<br></li>
                        <li data-aos="fade-up-right" style="font-size: 16px;color:  rgb(0,32,64);">Create unlimited pages<br></li>
                        <li data-aos="fade-up-right" style="font-size: 16px;color:  rgb(0,32,64);">Online reservations via email<br></li>
                        <li data-aos="fade-up-right" style="font-size: 16px;color:  rgb(0,32,64);">Video gallery<br></li>
                        <li data-aos="fade-up-right" style="font-size: 16px;color:  rgb(0,32,64);">Online chat<br></li>
                        <li data-aos="fade-up-right" style="font-size: 16px;color:  rgb(0,32,64);">Mobile/tablet compatibility<br></li>
                        <li data-aos="fade-up-right" style="font-size: 16px;color:  rgb(0,32,64);">Interactive maps<br></li>
                        <li data-aos="fade-up-right" style="font-size: 16px;color:  rgb(0,32,64);">Social media integration<br></li>
                    </ul>
                    <h2 data-aos="fade-up-right" style="color: rgb(0,32,64);">Our Web Development Processes?</h2>
                    <h2 data-aos="fade-up-right" style="font-size: 23px;color: rgb(0,32,64);line-height: 46px;font-weight: normal;">Review</h2>
                    <p data-aos="fade-up-right" style="font-family: Montserrat, sans-serif;color:  rgb(0,32,64);font-size: 16px;">We believe in getting to know your business requirements in-depth. It’s important that we understand your conditions of satisfaction. This will help us build a website that exceeds your expectations.<br></p>
                    <h2 data-aos="fade-up-right"
                        style="font-size: 23px;color: rgb(0,32,64);line-height: 46px;font-weight: normal;">Design</h2>
                    <p data-aos="fade-up-right" style="font-family: Montserrat, sans-serif;color:  rgb(0,32,64);font-size: 16px;">Working with you and your project budget in mind, we will design your website on a foundation of accuracy, quality, and flawless visual experience.<br></p>
                    <h2 data-aos="fade-up-right" style="font-size: 23px;color: rgb(0,32,64);line-height: 46px;font-weight: normal;">Develop</h2>
                    <p data-aos="fade-up-right" style="font-family: Montserrat, sans-serif;color:  rgb(0,32,64);font-size: 16px;">Development team members will implement necessary onsite changes and design required functionalities to deliver a website that sells. Down to the complete detail, we will conduct various split-testing and implement quality assurance
                        processes.<br></p>
                </div>
            </div>
        </div>
    </div>
    <div class="features-boxed" style="background-color: rgb(255,255,255);">
        <div class="container">
            <div class="intro">
                <h2 class="text-center" data-aos="fade-up-right" style="font-weight: normal;font-size: 32px;color: rgb(0,32,64);">Other Services</h2>
            </div>
            <div class="row features">
                <div class="col-sm-6 col-md-4 item">
                    <div class="box">
                        <div class="image-box"><img data-bs-hover-animate="swing" class="box-image img-responsive" src="assets/img/rf993ytl.jpg" style="height: 198px;"></div>
                        <div class="info-box">
                        <br> <h3 data-aos="fade-up-right" class="name" style="font-weight: normal;color: rgb(0,32,64);">Mobile Application Development</h3>
                            <p class="description" style="font-family: Montserrat, sans-serif;font-size: 16px;color:  rgb(0,32,64);">We develop mobile applications compatible with Android and IOS.</p><a class="learn-more" href="MobileApplicationDevelopment.php" style="font-size: 16px;font-family: Montserrat, sans-serif;color: rgb(125,0,0);">Learn more »</a></div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4 item">
                    <div class="box">
                        <div class="image-box"><img data-bs-hover-animate="swing" class="box-image img-responsive" src="assets/img/a-blueprint-on-iot-solutions-development-featured.jpg" style="height: 198px;"></div>
                        <br>
                        <div class="info-box">
                            <h3 data-aos="fade-up-right" class="name" style="color: rgb(0,32,64);font-weight: normal;">IoT</h3>
                            <p class="description" style="font-family: Montserrat, sans-serif;font-size: 16px;color:  rgb(0,32,64);">We offer IoT Technologies which applicable to various aspects of life.</p><a class="learn-more" href="iot.php" style="color: rgb(125,0,0);font-size: 16px;font-family: Montserrat, sans-serif;">Learn more »</a></div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4 item">
                    <div class="box">
                        <div class="image-box"><img data-bs-hover-animate="swing" class="box-image img-responsive" src="assets/img/gobinge-blog-2-1-1160x700.jpg" style="height: 198px;"></div>
                        <div class="info-box">
                            <br>
                            <h3 data-aos="fade-up-right" class="name" style="color: rgb(0,32,64);font-weight: normal;">ISP(Internet Service Provider)</h3>
                            <p class="description" style="font-family: Montserrat, sans-serif;font-size: 16px;color:  rgb(0,32,64);">We offer Internet Service Provider,Get your web hosted online.</p><a class="learn-more" href="ISP.php" style="font-family: Montserrat, sans-serif;color: rgb(125,0,0);font-size: 16px;">Learn more »</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-dark" style="font-family: 'Average Sans', sans-serif;background-color:  rgb(0,32,64);">
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item" style="font-family: Montserrat, sans-serif;">
                        <h3>Services</h3>
                        <ul>
                          
                            <li><a href="#" style="opacity: 1;">Internet Service Provider (ISP)</a></li>
          
                            <li><a href="#" style="opacity: 1;">Mobile App Development</a></li>
                            <li><a href="#" style="opacity: 1;">Internet of Things (IoT) </a></li>
                            <li><a href="#" style="opacity: 1;">Web Development </a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item" style="font-family: Montserrat, sans-serif;">
                        <h3>About</h3>
                        <ul>
                          
                            <li><a href="https://sacoronavirus.co.za" style="opacity: 1;">Covid 19</a></li>
                         
                        </ul>
                    </div>
                    <div class="col-md-6 item text" style="font-family: Montserrat, sans-serif;">
                        <h3>Bon Connect</h3>
                        <p style="opacity: 1;">We are focused on results and success. Stakeholder satisfaction is something we aim for. We adopt the principles of cooperative governance. Our products and services meet To be a world pioneer in ICT outsourcing and global base
                            solutions on an international scale.</p>
                    </div>
                    <div class="col item social"><a href="https://web.facebook.com/Bonconnect1?_rdc=1&amp;_rdr" style="background-color: #fff3f3;color:  rgb(0,32,64);opacity: 1;"><i class="icon ion-social-facebook"></i></a><a href="https://twitter.com/Bonconnect1" style="color:  rgb(0,32,64);background-color: #fff3f3;opacity: 1;"><i class="icon ion-social-twitter"></i></a>
                        <a
                            href="#" style="background-color: #fff3f3;opacity: 1;"><i class="icon ion-social-instagram" style="color:  rgb(0,32,64);"></i></a><a href="https://www.linkedin.com/in/bon-connect-6806661a4" style="background-color: #fff3f3;opacity: 1;"><i class="icon ion-social-linkedin" style="color:  rgb(0,32,64);"></i></a></div>
                </div>
                <p class="copyright" style="opacity: 1;font-family: Montserrat, sans-serif;">Bon Connect © 2015-<?php echo date("Y"); ?></p>
            </div>
        </footer>
    </div>
    

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="assets/js/Scroll-To-Top-Button.js"></script>
    <script src="assets/js/-Animated-numbers-section-BS4-.js"></script>
    <script src="assets/js/Animated-numbers-section.js"></script>
    <script src="assets/js/Cookie-bar-footer-popup.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/js-cookie/2.2.1/js.cookie.min.js"></script>
</body>

</html>