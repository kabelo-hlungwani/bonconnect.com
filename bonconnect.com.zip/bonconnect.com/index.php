<!DOCTYPE html>
<html>

<head>
<link rel="icon" href="assets/img/web.png">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Home-BonConnect</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alef">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alegreya+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Average+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cabin+Condensed">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lora">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/-product-features.css">
    <link rel="stylesheet" href="assets/css/Animated-numbers-section.css">
    <link rel="stylesheet" href="assets/css/Articale-List-With-Image-Zoom.css">
    <link rel="stylesheet" href="assets/css/Article-Clean.css">
    <link rel="stylesheet" href="assets/css/Article-List.css">
    <link rel="stylesheet" href="assets/css/Bold-BS4-Header-with-HTML5-Video-Background.css">
    <link rel="stylesheet" href="assets/css/Brands.css">
    <link rel="stylesheet" href="assets/css/Cookie-bar-footer-popup.css">
    <link rel="stylesheet" href="assets/css/dh-highlight-left-right.css">
    <link rel="stylesheet" href="assets/css/Features-Boxed.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="assets/css/Header-Dark.css">
    <link rel="stylesheet" href="assets/css/Highlight-Clean.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
    <link rel="stylesheet" href="assets/css/index-top-info-1.css">
    <link rel="stylesheet" href="assets/css/index-top-info.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Map-Clean.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
    <link rel="stylesheet" href="assets/css/Registration-Form-with-Photo.css">
    <link rel="stylesheet" href="assets/css/Scroll-To-Top-Button.css">
    <link rel="stylesheet" href="assets/css/Social-Menu-Sticky.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Team-Boxed.css">
    <link rel="stylesheet" href="assets/css/Team-Clean.css">
    <link rel="stylesheet" href="assets/css/TextOnVideo-1.css">
    <link rel="stylesheet" href="assets/css/TextOnVideo.css">

    
</head>


<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<body>
    <div class="d-flex flex-row align-items-center index-top-info" id="index-of-info" style="background-color: rgb(0,32,64);">
        <div class="container">
            <div class="row">
                <div class="col social-links">
                    <div class="float-left">
                        <ul>
                            <li><a href="https://web.facebook.com/Bonconnect1?_rdc=1&amp;_rdr"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://twitter.com/Bonconnect1"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="https://www.linkedin.com/in/bon-connect-6806661a4"><i class="fa fa-linkedin"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col contact-information">
                    <div class="float-right"><span data-aos="fade-up-left"><i class="fa fa-phone"></i>&nbsp;068 159 6956</span><span data-aos="fade-left"><i class="fa fa-envelope"></i>&nbsp;info@bonconnect.com</span></div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>




    <div id="home" href="#" style="font-family: Montserrat, sans-serif;">
        <div class="header-dark" style="background-image: url(&quot;assets/img/210888.jpg&quot;);">
            <nav class="navbar navbar-dark navbar-expand-md navigation-clean-search" style="font-family: Montserrat, sans-serif;">
                <div class="container"><img class="pulse animated infinite" src="assets/img/Untitled_design__1_-removebg-preview%20(1).png" style="height: 130px;filter: brightness(200%) contrast(200%) grayscale(100%) invert(0%) saturate(200%);font-size: 16px;"><button data-toggle="collapse" class="navbar-toggler"
                        data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navcol-1">
                        <ul class="nav navbar-nav">
                            <li class="nav-item" role="presentation"><a class="nav-link" href="#index-of-info">Home</a></li>
                            <li class="nav-item" role="presentation"><a class="nav-link" href="#features">About Us</a></li>
                            <li class="nav-item" role="presentation"><a class="nav-link" href="#contactmap">Contact Us</a></li>
                            <li class="dropdown nav-item"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#">Services&nbsp;</a>
                                <div class="dropdown-menu" role="menu" style="opacity: 1.0;">
                            
                               
                                <a class="dropdown-item" role="presentation" href="ISP.php">Internet Service Provider (ISP)</a>
                            
                                <a class="dropdown-item" role="presentation" href="MobileApplicationDevelopment.php">Mobile App Development </a>
                                <a class="dropdown-item" role="presentation" href="iot.php">Internet of Things (IoT)</a>
                                <a class="dropdown-item" role="presentation" href="webdevelopment.php">Web Application</a>
                            
                            </div>
                            </li>

                            <li class="dropdown nav-item"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#">Vacancies&nbsp;</a>
                                <div class="dropdown-menu" role="menu" style="opacity: 1.0;">
                                <a class="dropdown-item" role="presentation" href="vacancies.php">Internships / Learnerships</a>
                              
                            </div>
                            </li>
                           
                        </ul>
                    </div>
                </div>
                <div  id="google_translate_element" ></div>
            </nav>
            <div class="container hero">
                <div class="row">
                    <div class="col-md-8 offset-md-2">
                        <h2 class="text-center" data-aos="fade-right" style="font-family: Montserrat, sans-serif;color: rgb(255,255,255);">Background</h2>
                        <p data-aos="fade-right" style="font-family: Montserrat, sans-serif;color: rgb(255,255,255);font-size: 16px;"><br>
                            Bon Connect is a 100% black-owned company that was established in 2015. It is a true&nbsp;<br>
                            African-biased model with the characteristics of sound business in Africa. As a result of&nbsp;<br>
                            which its ownership is based on a black economic empowerment initiative in which&nbsp;<br>
                            shareholders carry XYL capital, black management and staff confidence and civil&nbsp;<br>organization.<br><br><br><br></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    




    <div class="highlight-clean">
      
        
            <div class="modal fade" role="dialog" tabindex="-1" id="signin">
                <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" style="color: rgb(0,32,64);">Sign Up Now</h4><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                        <div class="modal-body" style="font-family: Montserrat, sans-serif;">
                            <div class="text-center"><button class="btn text-left" style="width: 100%;background-color: rgb(0,32,64);color: rgb(255,255,255);" type="button"><i class="fa fa-facebook"></i>&nbsp; Continue with Facebook</button></div>
                            <div class="text-center mt-2"><button class="btn btn-light text-left border-dark" style="width: 100%;color: rgb(0,32,64);" type="button"><i class="fa fa-google" style="color: rgb(180,6,6);"></i>&nbsp; Continue with Google</button></div>
                          
                            <hr style="background-color: #bababa;">
                            <p class="text-center" style="color: rgb(0,32,64);">Already have an Account?&nbsp;<a class="text-decoration-none" data-dismiss="modal" data-toggle="modal" data-target="#signup" href="#" style="color: rgb(0,32,64);">Log In</a></p>
                        </div>
  
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid"></div>
    </div>
    <section id="features">
        <div id="container" class="container-fluid">
            <div id="row" class="row">
                <div class="col-lg-8 offset-lg-4">
                    <div class="ection-header wow fadeIn" style="visibility: visible; animation-duration: 1s; animation-name: fadeIn;" data-wow-duration="1s">
                        <h3 class="text-center section-title" style="color: rgb(0,32,64);font-size: 32px;">Who are we?</h3><span class="section-divider"></span></div>
                </div>
                <div class="col-lg-4 col-md-5 features-img"><img src="assets/img/features.png" style="filter: contrast(84%) grayscale(10%) hue-rotate(173deg) saturate(50%);"></div>
                <div class="col-lg-8 col-md-7">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 box wow fadeInRight" style="visibility: visible; animation-name: fadeInRight;">
                            <div><i class="icon ion-eye" style="font-size: 98px;color: rgb(0,32,64);"></i></div>
                            <h4 class="title" style="color: rgb(0,32,64);font-size: 32px;">Vision</h4>
                            <p class="text-left description" data-aos="fade-right" style="color: rgb(0,32,64);font-family: Montserrat, sans-serif;font-size: 16px;opacity: 0.8;">To be a world pioneer in ICT outsourcing and global base solutions on an international scale.<br></p>
                        </div>
                        <div class="col-lg-6 col-md-6 box wow fadeInRight" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInRight;" data-wow-delay="0.1s">
                            <div><i class="icon ion-ios-football" style="font-size: 98px;color: rgb(0,32,64);"></i></div>
                            <h4 class="title" style="color: rgb(0,32,64);font-size: 32px;">Mission</h4>
                            <p class="text-left description" data-aos="fade-left" style="color: rgb(0,32,64);font-family: Montserrat, sans-serif;font-size: 16px;opacity: 0.80;">To be an organization with a comprehensive value proposition that offers world quality and standards in the area of information technology. To serve as a focal point for a variety of excellent facilities.<br></p>
                        </div>
                        <div class="col-lg-6 col-md-6 box wow fadeInRight" data-wow-delay="0.2s" style="visibility: visible; animation-name: fadeInRight;">
                            <div><i class="fas fa-lightbulb" style="font-size: 98px;color: rgb(0,32,64);"></i></div>
                            <h4 class="title" style="color: rgb(0,32,64);font-size: 32px;"><strong>Value</strong><br></h4>
                            <p class="text-left description" data-aos="fade-left" style="color: rgb(0,32,64);font-family: Montserrat, sans-serif;font-size: 16px;opacity: 0.80;">We are focused on results and success. Stakeholder satisfaction is something we aim for. We adopt the principles of cooperative governance. Our products and services meet To be a world pioneer in ICT outsourcing and global
                                base solutions on an international scale.<br></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div id="contact" class="highlight-clean">
        <div class="container" style="background-color: #ffffff;opacity: 0.85;">
            <div class="intro">
                <h2 class="text-center" data-aos="fade-right" style="font-family: Montserrat, sans-serif;color: rgb(0,32,64);font-weight: normal;">About Us</h2>
                <p class="text-left" data-aos="zoom-in" style="font-family: Montserrat, sans-serif;font-weight: normal;color: #002040;">Bon Connect is committed to the employment equity concept enshrined in the Employment Equity Act, however, the international market requires Bon Connect to prepare ahead of time through its’ management succession strategy and policies.<br></p>
                <p
                    class="text-left" data-aos="zoom-in" style="font-family: Montserrat, sans-serif;font-weight: normal;color: #002040;">For its global operations policy, Bon Connect is working on diversity management and gender sensitivity and it has invested in an orientation program for new hires in the executive management program for company development and continuity.</p>
                    <p
                        class="text-left" data-aos="zoom-in" style="font-family: Montserrat, sans-serif;font-weight: normal;color: #002040;">Bon Connect is decided to empowering the majority of people in the countries where it works, for example, In South Africa, the majority of senior management is made up of black people,including black women. The cooperation has a 65%
                        female employment policy and an 80% youth employment policy.<br></p>
            </div>
        </div>
    </div>
    <div id="contactmap" href="#contact" target="_top">
        <div class="container">
            <div class="intro" style="font-family: Montserrat, sans-serif;">
                <h2 class="text-center" data-aos="fade-right" style="font-weight: normal;color: #002040;"><i class="icon ion-android-locate" style="color: rgb(0,32,64);"></i>Location </h2>
                <p class="text-center" style="color: #002040;font-size: 20px;">Find Us !</p>
            </div>
        </div><iframe allowfullscreen="" frameborder="0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyCEe3-wdRHXj_9rLAyN2SyQr6lkbWuH8i4&amp;q=88+Marshall+Street+%2C2nd+Floor+Samancor+House%2CMarshalltown%2CJohannesburg+%2C2107&amp;zoom=15" width="100%"
            height="450"></iframe></div>
    <div id="contact" href="#">
        <div class="container">
            <div class="row">
                <div class="col-md-12"></div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <form style="font-family: Montserrat, sans-serif;" action="contact.php" method="post"  >
                        <h3 style="color: rgb(0,32,64);"><i class="icon ion-android-mail"></i>&nbsp;contact</h3>
                        <hr>
                        <div class="form-group"><input class="form-control" type="text" name="name" placeholder="Name" style="color: rgb(0,32,64);" required=""></div>
                        <div class="form-group"><input class="form-control" type="text" name="contact" placeholder="Contact" style="color: rgb(0,32,64);" required=""></div>
                        <div class="form-group"><input class="form-control" type="text" name="email" placeholder="Email" style="color: rgb(0,32,64);" required=""></div>
                        <div class="form-group"><textarea class="form-control" rows="5" name="message" placeholder="Message" style="color: rgb(0,32,64);" required=""></textarea></div>
                        <div class="form-group text-center"><button class="btn border-white" type="submit" style="background-color: rgb(0,32,64);color: rgb(255,255,255);">Contact Us</button></div>
                    </form>
                </div>
                <div class="col-md-4">
                    <h3 style="color: rgb(0,32,64);"><i class="icon ion-ios-location"></i>&nbsp;Business address</h3>
                    <hr style="background-color: rgb(0,32,64);">
                    <p style="font-family: Montserrat, sans-serif;color: rgb(0,32,64);">88 Marshall Street&nbsp;<br>2nd Floor Samancor House<br>Marshalltown<br>Johannesburg&nbsp;<br>2107<br><br><a href="https://www.google.com/maps/place/88+Marshall+St,+Marshalltown,+Johannesburg,+2107/@-26.2078883,28.0381729,17z/data=!3m1!4b1!4m5!3m4!1s0x1e950ea2f3a07c3d:0x19a8ba5f9c1d36a!8m2!3d-26.2078883!4d28.0403616"
                            style="color: rgb(0,32,64);"><i class="icon ion-android-locate" style="color: rgb(0,32,64);"></i>Map Location link</a></p><a href="#"></a></div>
                <div class="col-md-4" style="color: rgb(0,32,64);">
                    <h3 style="color: rgb(0,32,64);"><i class="icon ion-android-time"></i>&nbsp;Working Hours</h3>
                    <hr style="background-color: rgb(0,32,64);">
                    <p style="font-family: Montserrat, sans-serif;">Mon - Fri &nbsp;8h00&nbsp;<i class="icon ion-ios-arrow-thin-right"></i> 17h00<br><br></p>
                    <h3 style="color: rgb(0,32,64);"><i class="icon ion-ios-telephone"></i>&nbsp;Contact Us</h3>
                    <hr style="background-color: rgb(0,32,64);">
                    <p style="font-family: Montserrat, sans-serif;">Tell No&nbsp;<i class="icon ion-ios-arrow-thin-right"></i>&nbsp;068 159 6956<br>Email <i class="icon ion-ios-arrow-thin-right"></i>&nbsp;Info@bonconnect.com<br></p>
                </div>
            </div>
        </div>
    </div>
   
    <div
        class="footer-dark" style="font-family: 'Average Sans', sans-serif;background-color: rgb(0,32,64);"><a class="btn btn-lg box-shadow" role="button" id="top" href="#" style="background-color: rgb(255,255,255);font-family: Montserrat, sans-serif;"><i class="icon ion-android-arrow-up" style="background-color: #ffffff;color: rgb(0,32,64);"></i></a>
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item" style="font-family: Montserrat, sans-serif;">
                        <h3>Services</h3>
                        <ul>
                   
                            <li><a href="#" style="opacity: 1;">Internet Service Provider (ISP)</a></li>
              
                            <li><a href="#" style="opacity: 1;">Mobile App Development</a></li>
                            <li><a href="#" style="opacity: 1;">Internet of Things (IoT) </a></li>
                            <li><a href="#" style="opacity: 1;">Web Development </a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item" style="font-family: Montserrat, sans-serif;">
                        <h3>About</h3>
                        <ul>
                            <li><a href="https://sacoronavirus.co.za" style="opacity: 1;">Covid 19</a></li>
                         
                        </ul>
                    </div>
                    <div class="col-md-6 item text" style="font-family: Montserrat, sans-serif;">
                        <h3>Bon Connect</h3>
                        <p style="opacity: 1;">We are focused on results and success. Stakeholder satisfaction is something we aim for. We adopt the principles of cooperative governance. Our products and services meet To be a world pioneer in ICT outsourcing and global base
                            solutions on an international scale.</p>
                    </div>
                    <div class="col item social"><a href="https://web.facebook.com/Bonconnect1?_rdc=1&amp;_rdr" style="background-color: #fff3f3;color: rgb(0,32,64);opacity: 1;"><i class="icon ion-social-facebook"></i></a><a href="https://twitter.com/Bonconnect1" style="color: rgb(0,32,64);background-color: #fff3f3;opacity: 1;"><i class="icon ion-social-twitter"></i></a>
                        <a
                            href="#" style="background-color: #fff3f3;opacity: 1;"><i class="icon ion-social-instagram" style="color: rgb(0,32,64);"></i></a><a href="https://www.linkedin.com/in/bon-connect-6806661a4" style="background-color: #fff3f3;opacity: 1;"><i class="icon ion-social-linkedin" style="color: rgb(0,32,64);"></i></a></div>
                </div>
                <p class="copyright" style="opacity: 1;font-family: Montserrat, sans-serif;">Bon Connect © 2015-<?php echo date("Y"); ?></p>
            </div>
        </footer>
        </div>
        <div id="fixed-social">
        <div><a class="fixed-facebook" href="#" target="_blank" style="background: rgb(0,32,64);"><i class="fa fa-facebook"></i></a></div>
        <div><a class="fixed-instagram" href="#" target="_blank" style="background: rgb(0,32,64);"><i class="fa fa-instagram"></i></a></div>
        <div></div>
        <div><a class="fixed-youtube" href="#" target="_blank" style="background: rgb(0,32,64);"><i class="fa fa-twitter"></i></a></div>
        <div><a class="fixed-youtube" href="#" target="_blank" style="background: rgb(0,32,64);"><i class="fa fa-whatsapp"></i></a></div>
    </div>
    <section>
        <div class="alert text-center cookiealert" role="alert" style="font-family: Montserrat, sans-serif;background: rgb(0,32,64);opacity: 0.90;">
            <p> This website stores cookies on your computer. These cookies are used to collect information about how you interact with our website and allow us to remember you. We use this information in order to improve and customize your browsing experience and for analytics and metrics about our visitors both on this website and other media. To find out more about the cookies we use, see our Privacy Policy. </p>
            <button class="btn btn btn-primary btn-sm acceptcookies" type="button" aria-label="Close" style="color: rgb(0,32,64);background: rgb(255,255,255);font-family: Montserrat, sans-serif;border-style: none;">Accept</button>
            <button class="btn btn btn-primary btn-sm acceptcookies" type="button" aria-label="Close" style="color: rgb(0,32,64);background: rgb(255,255,255);font-family: Montserrat, sans-serif;border-style: none;">Decline</button>
        </div>
    </section>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="assets/js/Scroll-To-Top-Button.js"></script>
    <script src="assets/js/-Animated-numbers-section-BS4-.js"></script>
    <script src="assets/js/Animated-numbers-section.js"></script>
    <script src="assets/js/Cookie-bar-footer-popup.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/js-cookie/2.2.1/js.cookie.min.js"></script>
</body>

</html>