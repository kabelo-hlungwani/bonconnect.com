<?php


include 'connectdb.php'; 


$fname=$_POST['firstname'];
$lname=$_POST['lastname'];
$contact=$_POST['contact'];
$email=$_POST['email'];
$password=md5($_POST['password']);






$query="select * from member where email='$email'";

$result=mysqli_query($conn,$query) or die(mysqli_error($conn));

$row=mysqli_fetch_array($result);


if($_POST['register'])
{



    if($email==$row['email'])
    {
    
        echo '<script type="text/javascript">alert("email account exist please login"); window.location = "index.php";</script>';

         exit;



    }else{


$sql="INSERT INTO member( name, surname, contact_number, email, password)
            VALUES ('$fname','$lname','$contact','$email','$password')";

            if(mysqli_query($conn,$sql))
            {
    
             echo '<script type="text/javascript">alert("You Succesfully Registered Please Login Your Account"); window.location = "index.php";</script>';
         
                                                   
          }
          else{
            
           die("<h3>unsuccessfully not registered </h3>".mysqli_error($conn));
         
         }



}



    }



       
   
   
?>