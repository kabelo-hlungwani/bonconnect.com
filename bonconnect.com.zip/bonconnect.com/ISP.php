<!DOCTYPE html>
<html>

<head>
<link rel="icon" href="assets/img/web.png">
<title>ISP</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>new 2nd bon con</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alef">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alegreya+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Average+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cabin+Condensed">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lora">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
    <link rel="stylesheet" href="assets/css/-product-features.css">
    <link rel="stylesheet" href="assets/css/Article-Clean.css">
    <link rel="stylesheet" href="assets/css/dh-highlight-left-right.css">
    <link rel="stylesheet" href="assets/css/Features-Boxed-Remixed-1.css">
    <link rel="stylesheet" href="assets/css/Features-Boxed-Remixed-2.css">
    <link rel="stylesheet" href="assets/css/Features-Boxed-Remixed.css">
    <link rel="stylesheet" href="assets/css/Features-Boxed.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="assets/css/Header-Dark.css">
    <link rel="stylesheet" href="assets/css/Highlight-Clean.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div>
        <div class="header-dark" style="background-image: url(&quot;assets/img/bg.png&quot;);font-family: Montserrat, sans-serif;height: 500px;filter: contrast(139%) saturate(117%);">
        <nav class="navbar navbar-dark navbar-expand-md navigation-clean-search" style="font-family: Montserrat, sans-serif;">
                <div class="container"><a href="index.php"><img class="pulse animated infinite" src="assets/img/Untitled_design__1_-removebg-preview%20(1).png" style="height: 130px;filter: brightness(200%) contrast(200%) grayscale(100%) invert(0%) saturate(200%);font-size: 16px;"></a><button data-toggle="collapse" class="navbar-toggler"
                        data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navcol-1">
                        <ul class="nav navbar-nav">
                            <li class="nav-item" role="presentation"><a class="nav-link" href="index.php">Home</a></li>
                            <li class="nav-item" role="presentation"><a class="nav-link" href="#features">About Us</a></li>
                            <li class="nav-item" role="presentation"><a class="nav-link" href="#contactmap">Contact Us</a></li>
                            <li class="dropdown nav-item"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#">Services&nbsp;</a>
                                <div class="dropdown-menu" role="menu" style="opacity: 1.0;">
                            
                               
                                <a class="dropdown-item" role="presentation" href="ISP.php">Internet Service Provider (ISP)</a>
                            
                                <a class="dropdown-item" role="presentation" href="MobileApplicationDevelopment.php">Mobile App Development </a>
                                <a class="dropdown-item" role="presentation" href="iot.php">Internet of Things (IoT)</a>
                                <a class="dropdown-item" role="presentation" href="webdevelopment.php">Web Development</a>
                            
                            </div>
                            </li>

                            <li class="dropdown nav-item"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#">Vacancies&nbsp;</a>
                                <div class="dropdown-menu" role="menu" style="opacity: 1.0;">
                                <a class="dropdown-item" role="presentation" href="vacancies.php">Internships / Learnerships</a>
                              
                            </div>
                            </li>
                            
                        </ul>
                    </div>
                </div>
                <div  id="google_translate_element" ></div>
            </nav>
    </div>
    </div>
    <div class="article-clean">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-xl-8 offset-lg-1 offset-xl-2">
                   <br>
                   <br>
                    <h1 class="text-left" data-aos="fade-up-right" style="color:  rgb(0,32,64);font-weight: normal;">Internet Service Provider(ISP)<br></h1>
                    <div class="text">
                        <h2 data-aos="fade-up-right" style="font-size: 23px;color:  rgb(0,32,64);line-height: 46px;font-weight: normal;">What is Internet Service Provider(ISP)?</h2>
                        <p data-aos="fade-up-right" style="font-family: Montserrat, sans-serif;color: rgb(33,32,50);">Internet service provider&nbsp;(ISP), company that provides Internet connections and services to individuals and organizations. In addition to providing access to the Internet,&nbsp;ISPs&nbsp;may also provide software packages
                            (such as browsers), e-mail accounts, and a personal Web site or home page.<br></p>
                        <h2 data-aos="fade-up-right" style="font-size: 32px;line-height: 46px;font-weight: normal;color:  rgb(0,32,64);">ISP Types<br></h2>
                        <ul>
                            <li data-aos="fade-up-right" style="font-size: 16px;color: rgb(0,32,64);font-family: Montserrat, sans-serif;"><strong>Access providers</strong>&nbsp;- They provide access to internet through telephone lines, cable wi-fi or fiber optics.<br></li>
                            <li data-aos="fade-up-right" style="font-size: 16px;color: rgb(0,32,64);font-family: Montserrat, sans-serif;"><strong>Mailbox Provider</strong> - Such providers offer mailbox hosting services.<br></li>
                            <li data-aos="fade-up-right" style="font-size: 16px;color: rgb(0,32,64);font-family: Montserrat, sans-serif;"><strong>Hosting ISPs</strong> - Hosting ISPs offers e-mail, and other web hosting services such as virtual machines, clouds.<br></li>
                            <li data-aos="fade-up-right" style="font-size: 16px;color: rgb(0,32,64);font-family: Montserrat, sans-serif;"><strong>Virtual ISPs</strong> - Such ISPs offer internet access via other ISP services.<br></li>
                            <li data-aos="fade-up-right" style="font-size: 16px;color: rgb(0,32,64);font-family: Montserrat, sans-serif;"><strong>Free ISPs -&nbsp;</strong>Free ISPs do not charge for internet services<br></li>
                        </ul>
                    </div>
                    <h2 data-aos="fade-up-right" style="color:  rgb(0,32,64);">Connection Types<br></h2>
                    <ul></ul>
                    <p data-aos="fade-up-right" style="font-family: Montserrat, sans-serif;color: rgb(0,32,64);font-size: 16px;">ISPs use a range of technologies to enable customers' connection to their network. The most common&nbsp;types of internet connections&nbsp;include:<br></p>
                    <ul>
                        <li data-aos="fade-up-right" style="font-size: 16px;color: rgb(0,32,64);font-family: Montserrat, sans-serif;">DSL (digital subscriber line)<br></li>
                        <li data-aos="fade-up-right" style="font-size: 16px;color: rgb(0,32,64);font-family: Montserrat, sans-serif;">Cable broadband<br></li>
                        <li data-aos="fade-up-right" style="font-size: 16px;color: rgb(0,32,64);font-family: Montserrat, sans-serif;">Fibre optic&nbsp;broadband<br></li>
                        <li data-aos="fade-up-right" style="font-size: 16px;color: rgb(0,32,64);font-family: Montserrat, sans-serif;">Wireless or Wi-Fi broadband<br></li>
                        <li data-aos="fade-up-right" style="font-size: 16px;color: rgb(0,32,64);font-family: Montserrat, sans-serif;">Satellite and mobile broadband<br></li>
                        <li data-aos="fade-up-right" style="font-size: 16px;color: rgb(0,32,64);font-family: Montserrat, sans-serif;">Dedicated leased line<br></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="features-boxed" style="background-color: rgb(255,255,255);">
        <div class="container">
            <div class="intro">
                <h2 class="text-center" data-aos="fade-up-right" style="font-weight: normal;font-size: 32px;color:  rgb(0,32,64);">Other Services</h2>
            </div>
            <div class="row features">
                <div class="col-sm-6 col-md-4 item">
                    <div class="box">
                        <div class="image-box"><img data-bs-hover-animate="swing" class="box-image img-responsive" src="assets/img/top-20-programming-languages-used-for-web-development.jpg" style="height: 198px;"></div>
                        <div class="info-box">
                        <br>  <h3 data-aos="fade-up-right" class="name" style="font-weight: normal;color:  rgb(0,32,64);">Web Development</h3>
                            <p class="description" style="font-family: Montserrat, sans-serif;font-size: 16px;color: rgb(0,32,64);">We develop web applications / websites compatible to any device.</p><a class="learn-more" href="webdevelopment.php" style="font-size: 16px;font-family: Montserrat, sans-serif;color:  rgb(125,0,0);">Learn more »</a></div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4 item">
                    <div class="box">
                        <div class="image-box"><img data-bs-hover-animate="swing" class="box-image img-responsive" src="assets/img/rf993ytl.jpg" style="height: 198px;"></div>
                        <div class="info-box">
                        <br> <h3 data-aos="fade-up-right" class="name" style="color:  rgb(0,32,64);font-weight: normal;">Mobile Application Development</h3>
                            <p class="description" style="font-family: Montserrat, sans-serif;font-size: 16px;color: rgb(0,32,64);">We develop mobile applications compatible with Android and IOS<br></p><a class="learn-more" href="MobileApplicationDevelopment.php" style="color:  rgb(125,0,0);font-size: 16px;font-family: Montserrat, sans-serif;">Learn more »</a></div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4 item">
                    <div class="box">
                        <div class="image-box"><img data-bs-hover-animate="swing" class="box-image img-responsive" src="assets/img/a-blueprint-on-iot-solutions-development-featured.jpg" style="height: 198px;"></div>
                        <div class="info-box">
                        <br> <h3 data-aos="fade-up-right" class="name" style="color:  rgb(0,32,64);font-weight: normal;">IoT</h3>
                            <p class="description" style="font-family: Montserrat, sans-serif;font-size: 16px;color: rgb(0,32,64);">We offer IoT Technologies which applicable to various aspects of life.<br></p><a class="learn-more" href="iot.php" style="font-family: Montserrat, sans-serif;color:  rgb(125,0,0);font-size: 16px;">Learn more »</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-dark" style="font-family: 'Average Sans', sans-serif;background-color: rgb(0,32,64);">
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item" style="font-family: Montserrat, sans-serif;">
                        <h3>Services</h3>
                        <ul>
                            
                     
                            <li><a href="#" style="opacity: 1;">Internet Service Provider (ISP)</a></li>
                         
                            <li><a href="#" style="opacity: 1;">Mobile App Development</a></li>
                            <li><a href="#" style="opacity: 1;">Internet of Things (IoT) </a></li>
                            <li><a href="#" style="opacity: 1;">Web Development </a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item" style="font-family: Montserrat, sans-serif;">
                        <h3>About</h3>
                        <ul>
                       
                            <li><a href="https://sacoronavirus.co.za" style="opacity: 1;">Covid 19</a></li>
                            <li><a style="opacity: 1;" href="profile.html">Profile</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text" style="font-family: Montserrat, sans-serif;">
                        <h3>Bon Connect</h3>
                        <p style="opacity: 1;">We are focused on results and success. Stakeholder satisfaction is something we aim for. We adopt the principles of cooperative governance. Our products and services meet To be a world pioneer in ICT outsourcing and global base
                            solutions on an international scale.</p>
                    </div>
                    <div class="col item social"><a href="https://web.facebook.com/Bonconnect1?_rdc=1&amp;_rdr" style="background-color: #fff3f3;color: rgb(0,32,64);opacity: 1;"><i class="icon ion-social-facebook"></i></a><a href="https://twitter.com/Bonconnect1" style="color: rgb(0,32,64);background-color: #fff3f3;opacity: 1;"><i class="icon ion-social-twitter"></i></a>
                        <a
                            href="#" style="background-color: #fff3f3;opacity: 1;"><i class="icon ion-social-instagram" style="color: rgb(0,32,64);"></i></a><a href="https://www.linkedin.com/in/bon-connect-6806661a4" style="background-color: #fff3f3;opacity: 1;"><i class="icon ion-social-linkedin" style="color: rgb(0,32,64);"></i></a></div>
                </div>
                <p class="copyright" style="opacity: 1;font-family: Montserrat, sans-serif;">Bon Connect © 2015-<?php echo date("Y"); ?></p>
            </div>
        </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-animation.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.js"></script>
</body>

</html>