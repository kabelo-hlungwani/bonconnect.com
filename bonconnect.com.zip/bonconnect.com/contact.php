<?php


include 'connectdb.php'; 


$name=$_POST['name'];
$contact=$_POST['contact'];
$email=$_POST['email'];
$message=$_POST['message'];



$sql="INSERT INTO contact (name, contact_number, email, message)
            VALUES ('$name','$contact','$email','$message')";

            if(mysqli_query($conn,$sql))
            {
    
             echo '<script type="text/javascript">alert("Your Message was sent wait for feedback Succesfully "); window.location = "index.php";</script>';
         
                                                   
          }
          else{
            
           die("<h3>unsuccessfully not registered </h3>".mysqli_error($conn));
         
         }
       
   
   
?>

