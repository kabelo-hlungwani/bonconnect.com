<!DOCTYPE html>
<html>

<head>
<link rel="icon" href="assets/img/web.png">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Internships / learnerships Page</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alef">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alegreya+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Average+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cabin+Condensed">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/line-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/-product-features.css">
    <link rel="stylesheet" href="assets/css/3-Cards-per-Row.css">
    <link rel="stylesheet" href="assets/css/Animated-gradient-background-1.css">
    <link rel="stylesheet" href="assets/css/Animated-gradient-background-2.css">
    <link rel="stylesheet" href="assets/css/Animated-gradient-background.css">
    <link rel="stylesheet" href="assets/css/Boostrap-Tabs.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-4---Tabs-with-Arrows.css">
    <link rel="stylesheet" href="assets/css/card-3-column-animation-shadows-images.css">
    <link rel="stylesheet" href="assets/css/dh-highlight-left-right.css">
    <link rel="stylesheet" href="assets/css/Features-Boxed.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="assets/css/Header-Dark.css">
    <link rel="stylesheet" href="assets/css/Highlight-Clean.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/Left-SideMenu.css">
    <link rel="stylesheet" href="assets/css/Login-Form-blue-Gradient-1.css">
    <link rel="stylesheet" href="assets/css/Login-Form-blue-Gradient.css">
    <link rel="stylesheet" href="assets/css/menu-cinel-1.css">
    <link rel="stylesheet" href="assets/css/menu-cinel.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="assets/css/Nice-breadcrumb.css">
    <link rel="stylesheet" href="assets/css/Sidebar-Menu-1.css">
    <link rel="stylesheet" href="assets/css/Sidebar-Menu.css">
    <link rel="stylesheet" href="assets/css/SIdebar-Responsive-2-1.css">
    <link rel="stylesheet" href="assets/css/SIdebar-Responsive-2.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Tabbed-Panel.css">
    <link rel="stylesheet" href="assets/css/Tamplate-SB-Admin-on-BSS.css">
</head>

<body style="background: #ffffff;">
    <div></div>
    <nav class="navbar navbar-light navbar-expand-md shadow navigation-clean-button" style="font-family: Montserrat, sans-serif;background: rgb(0,32,64);opacity: 0.92;color: rgb(255,255,255);">
        <div class="container"><a href="index.php"><img class="rubberBand animated infinite" src="assets/img/Untitled_design__1_-removebg-preview%20(1).png" style="height: 125px;"></a></div>
    </nav>
    <section id="gradient">
        <div class="d-xl-flex justify-content-xl-center align-items-xl-center text-center your-text">
            <h1 data-aos="fade-down-right" class="tex" style="color: rgb(255,255,255);">Check available Jobs below.</h1>
        </div>
        <p data-aos="fade-up-right" class="grad-text text-center" style="font-family: Montserrat, sans-serif;color: #ffffff;">Find learnerships and internships.</p>
    </section>
    <p class="text-center" style="font-family: Montserrat, sans-serif;font-weight: bold;font-size: 18px;color: rgb(21,50,80);padding-top: 6px;border-color: rgb(255,255,255);background: #ffffff;"><a href="index.php" style="color: rgb(21,50,80);font-size: 27px;"><i class="la la-home" style="color: rgb(21,50,80);font-size: 24px;"></i>Home</a>&nbsp;/ Available Jobs</p>
    <section class="bg-light">
        <div class="container">
            <div class="row" style="font-family: Montserrat, sans-serif;padding-bottom: 26px;">
                <div class="col-sm-10 col-md-6 col-lg-4 offset-sm-1 offset-md-0 order-md-1 order-lg-1" style="margin-top: 20px;">
                    <div class="shadow bg-white" data-aos="fade" data-aos-duration="600" data-aos-delay="200" data-aos-once="true" style="border-radius: 16px;">
                        <div style="margin-top: 12px;padding: 12px;">
                            <h1 style="color: #002040;font-size: 24px;"><strong>Receptionist</strong><br></h1>
                            <p style="font-weight: bold;color: rgb(0,32,64);">Lynx Professional Service&nbsp;-&nbsp;Johannesburg, Gauteng<br></p>
                            <p style="font-weight: bold;color: rgb(0,32,64);">Category : Internship&nbsp;</p>
                            <p style="font-weight: bold;color: rgb(0,32,64);">Full time / Permanent</p>
                            <hr>
                            <p style="font-family: Montserrat, sans-serif;font-size: 15px;margin-top: 10px;font-weight: bold;color: rgb(0,32,64);">Job Description :</p>
                            <p style="font-family: Montserrat, sans-serif;font-size: 15px;margin-top: 10px;font-weight: normal;color: rgb(0,32,64);"><br>Established company looking for a AUTOCAD specialist to work on complicated and big projects . Knowledge of Architecture drafting is essential , attention to details and understanding of how to work on big complexes and difficult homes. Team of AUTOCAD specialist already established and working together for close to 3 years. Work sharing is a skill that will be taught , joining the company will only advance your knowledge of Revit and sharing of this knowledge will benefit both the company and candidate.<br><br>If this sounds like you, don't let this opportunity go and apply today as we are keen on employing energetic staff immediately who are keen on join the already established Revit team of dynamic staff.<br><br><br>Job Type: Full-time<br><br>Job Type: Permanent<br><br><strong>Experience: </strong><br>Drafting: 1 year (Required)<br>AutoCAD: 3 years (Required)<br>CAD: 2 years (Required)Work <br><br>Remotely: Yes<br><br><strong>COVID-19 Precaution(s):</strong><br><br>*Remote interview process<br>*Personal protective equipment provided or required *Temperature screenings <br>*Social distancing guidelines in place *Virtual meetings<br>*Sanitizing, disinfecting, or cleaning&nbsp; &nbsp; &nbsp; &nbsp;procedures in place<br><br><br></p>
                            <p style="font-weight: normal;color: rgb(0,32,64);">Post is 30 days old</p>
                            <hr><button class="btn" type="submit" style="background: #002040;color: rgb(255,255,255);">Apply Now !</button>
                        </div>
                    </div>
                </div>
                <div class="col-sm-10 col-md-6 col-lg-4 offset-sm-1 offset-md-0 order-md-1 order-lg-1" style="margin-top: 20px;">
                    <div class="shadow bg-white" data-aos="fade" data-aos-duration="600" data-aos-delay="200" data-aos-once="true" style="border-radius: 16px;">
                        <div style="margin-top: 12px;padding: 12px;">
                            <h1 style="color: #002040;font-size: 24px;"><strong>Receptionist</strong><br></h1>
                            <p style="font-weight: bold;color: rgb(0,32,64);">Lynx Professional Service&nbsp;-&nbsp;Johannesburg, Gauteng<br></p>
                            <p style="font-weight: bold;color: rgb(0,32,64);">Category : Internship&nbsp;</p>
                            <p style="font-weight: bold;color: rgb(0,32,64);">Full time / Permanent</p>
                            <hr>
                            <p style="font-family: Montserrat, sans-serif;font-size: 15px;margin-top: 10px;font-weight: bold;color: rgb(0,32,64);">Job Description :</p>
                            <p style="font-family: Montserrat, sans-serif;font-size: 15px;margin-top: 10px;font-weight: normal;color: rgb(0,32,64);"><br>Established company looking for a AUTOCAD specialist to work on complicated and big projects . Knowledge of Architecture drafting is essential , attention to details and understanding of how to work on big complexes and difficult homes. Team of AUTOCAD specialist already established and working together for close to 3 years. Work sharing is a skill that will be taught , joining the company will only advance your knowledge of Revit and sharing of this knowledge will benefit both the company and candidate.<br><br>If this sounds like you, don't let this opportunity go and apply today as we are keen on employing energetic staff immediately who are keen on join the already established Revit team of dynamic staff.<br><br><br>Job Type: Full-time<br><br>Job Type: Permanent<br><br><strong>Experience: </strong><br>Drafting: 1 year (Required)<br>AutoCAD: 3 years (Required)<br>CAD: 2 years (Required)Work <br><br>Remotely: Yes<br><br><strong>COVID-19 Precaution(s):</strong><br><br>*Remote interview process<br>*Personal protective equipment provided or required *Temperature screenings <br>*Social distancing guidelines in place *Virtual meetings<br>*Sanitizing, disinfecting, or cleaning&nbsp; &nbsp; &nbsp; &nbsp;procedures in place<br><br><br></p>
                            <p style="font-weight: normal;color: rgb(0,32,64);">Post is 30 days old</p>
                            <hr><button class="btn" type="submit" style="background: #002040;color: rgb(255,255,255);">Apply Now !</button>
                        </div>
                    </div>
                </div>
                <div class="col-sm-10 col-md-6 col-lg-4 offset-sm-1 offset-md-0 order-md-1 order-lg-1" style="margin-top: 20px;">
                    <div class="shadow bg-white" data-aos="fade" data-aos-duration="600" data-aos-delay="200" data-aos-once="true" style="border-radius: 16px;">
                        <div style="margin-top: 12px;padding: 12px;">
                            <h1 style="color: #002040;font-size: 24px;"><strong>Receptionist</strong><br></h1>
                            <p style="font-weight: bold;color: rgb(0,32,64);">Lynx Professional Service&nbsp;-&nbsp;Johannesburg, Gauteng<br></p>
                            <p style="font-weight: bold;color: rgb(0,32,64);">Category : Internship&nbsp;</p>
                            <p style="font-weight: bold;color: rgb(0,32,64);">Full time / Permanent</p>
                            <hr>
                            <p style="font-family: Montserrat, sans-serif;font-size: 15px;margin-top: 10px;font-weight: bold;color: rgb(0,32,64);">Job Description :</p>
                            <p style="font-family: Montserrat, sans-serif;font-size: 15px;margin-top: 10px;font-weight: normal;color: rgb(0,32,64);"><br>Established company looking for a AUTOCAD specialist to work on complicated and big projects . Knowledge of Architecture drafting is essential , attention to details and understanding of how to work on big complexes and difficult homes. Team of AUTOCAD specialist already established and working together for close to 3 years. Work sharing is a skill that will be taught , joining the company will only advance your knowledge of Revit and sharing of this knowledge will benefit both the company and candidate.<br><br>If this sounds like you, don't let this opportunity go and apply today as we are keen on employing energetic staff immediately who are keen on join the already established Revit team of dynamic staff.<br><br><br>Job Type: Full-time<br><br>Job Type: Permanent<br><br><strong>Experience: </strong><br>Drafting: 1 year (Required)<br>AutoCAD: 3 years (Required)<br>CAD: 2 years (Required)Work <br><br>Remotely: Yes<br><br><strong>COVID-19 Precaution(s):</strong><br><br>*Remote interview process<br>*Personal protective equipment provided or required *Temperature screenings <br>*Social distancing guidelines in place *Virtual meetings<br>*Sanitizing, disinfecting, or cleaning&nbsp; &nbsp; &nbsp; &nbsp;procedures in place<br><br><br></p>
                            <p style="font-weight: normal;color: rgb(0,32,64);">Post is 30 days old</p>
                            <hr><button class="btn" type="submit" style="background: #002040;color: rgb(255,255,255);">Apply Now !</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="footer-dark" style="font-family: Montserrat, sans-serif;background-color: rgb(0,32,64);">
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item" style="font-family: Montserrat, sans-serif;">
                        <h3>Services</h3>
                        <ul>
                            <li><a href="#" style="opacity: 1;">Cloud Computing</a></li>
                            <li><a href="#" style="opacity: 1;">Mobile Solution</a></li>
                            <li><a href="#" style="opacity: 1;">Broadband &amp; Wi-Fi Solution </a></li>
                            <li><a href="#" style="opacity: 1;">Telecommunication Solution </a></li>
                            <li><a href="#" style="opacity: 1;">Business Process Outstanding&nbsp;</a></li>
                            <li><a href="#" style="opacity: 1;">Internet Service Provider (ISP)</a></li>
                            <li><a href="#" style="opacity: 1;">Managed IT &amp; Security System</a></li>
                            <li><a href="#" style="opacity: 1;">Integration &amp; Data Centre</a></li>
                            <li><a href="#" style="opacity: 1;">Mobile App Development</a></li>
                            <li><a href="#" style="opacity: 1;">Internet of Things (IoT) </a></li>
                            <li><a href="#" style="opacity: 1;">Web Development </a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item" style="font-family: Montserrat, sans-serif;">
                        <h3>About</h3>
                        <ul>
                            <li><a href="#" style="opacity: 1;">Structure</a></li>
                            <li><a href="#" style="opacity: 1;">Team</a></li>
                            <li><a href="#" style="opacity: 1;">Vacancies</a></li>
                            <li><a href="#" style="opacity: 1;">Covid 19</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text" style="font-family: Montserrat, sans-serif;">
                        <h3>Bon Connect</h3>
                        <p style="opacity: 1;">We are focused on results and success. Stakeholder satisfaction is something we aim for. We adopt the principles of cooperative governance. Our products and services meet To be a world pioneer in ICT outsourcing and global base solutions on an international scale.</p>
                    </div>
                    <div class="col item social"><a href="#" style="background-color: #fff3f3;color: rgb(0,32,64);opacity: 1;"><i class="icon ion-social-facebook"></i></a><a href="#" style="color: rgb(0,32,64);background-color: #fff3f3;opacity: 1;"><i class="icon ion-social-twitter"></i></a><a href="#" style="background-color: #fff3f3;opacity: 1;"><i class="icon ion-social-instagram" style="color: rgb(0,32,64);"></i></a><a href="#" style="background-color: #fff3f3;opacity: 1;"><i class="icon ion-social-whatsapp-outline" style="color: rgb(0,32,64);"></i></a></div>
                </div>
                <p class="copyright" style="opacity: 1;font-family: Montserrat, sans-serif;">Bon Connect © 2015-2021</p>
            </div>
        </footer>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="assets/js/Animated-gradient-background.js"></script>
    <script src="assets/js/Sidebar-Menu.js"></script>
</body>

</html>